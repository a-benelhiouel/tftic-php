<?php
$message = "";
// vérifier si déjà essayé de se connecter
if (isset($_SESSION["count"])) {
    $message = "Veuillez vous connecter";

}
// si 1x sur la page
else
{
    $_SESSION["count"] = 1;
}


// si le formulaire a été soumis
if (isset($_POST["nom"])) {
    // vérifer que le champ n'est pas vide
    if($_POST["nom"] != "")
    {
        // enregistrer le nom dans variable session
        $_SESSION["nom"] = $_POST["nom"];
        // rediriger vers la page d'accueil
        header("Location:index.php?section=accueil");
    }
}



include("view/page/connexion.php");

?>
