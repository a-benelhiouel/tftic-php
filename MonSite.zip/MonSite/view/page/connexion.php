<h2>Connexion</h2>
<form action="#" method="post">
    <label for="nom">Nom :</label>
    <input type="text" name="nom" id="nom">
    <input type="submit" value="Connexion">
</form>
<p><?= $message; ?></p>