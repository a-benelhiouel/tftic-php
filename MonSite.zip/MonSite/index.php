<?php
session_start();
include("view/html/header.php");
include("view/menu/menu.php");
include("controller/router.php");

include("view/html/footer.php");
?>